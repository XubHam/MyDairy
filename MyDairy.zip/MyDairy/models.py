from django.db import models

class Signup(models.Model):
    Password=models.CharField
